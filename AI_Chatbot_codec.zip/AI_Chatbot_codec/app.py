
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def chatbot_response(message):
    message = message.lower().strip()

    if any(word in message for word in ["hello", "hi", "hey"]):
        return "Hello! Welcome to our chatbot. How can I help you?"

    elif "your name" in message:
        return "I am Satya's AI Chatbot."

    elif "internship" in message:
        return "An internship helps you gain practical skills and experience."

    elif "python" in message:
        return "Python is a programming language used in AI, data analysis, and web development."

    elif "skills" in message:
        return "You can learn Python, SQL, data analysis, and web development."

    elif "thank" in message:
        return "You're welcome! Happy to help."

    elif "bye" in message:
        return "Goodbye! Have a great day."

    else:
        return "Sorry, I don't know that answer yet. Try asking about Python, skills, or internships."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    message = data.get("message", "").strip()

    if not message:
        return jsonify({"reply": "Please type a message."})

    reply = chatbot_response(message)
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)
